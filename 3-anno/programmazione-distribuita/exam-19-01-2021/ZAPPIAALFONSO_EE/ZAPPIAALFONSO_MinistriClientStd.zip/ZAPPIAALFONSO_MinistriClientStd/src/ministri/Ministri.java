/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;
// sono stati aggiunti tutti gli import mancanti nell'esame
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;
import static ministri.Ministri.FIND_ALL;
import static ministri.Ministri.FIND_BY_COGNOME;
import static ministri.Ministri.FIND_BY_DIPENDENTI;
import static ministri.Ministri.FIND_BY_ID;
import static ministri.Ministri.FIND_BY_MINISTERO;
import static ministri.Ministri.FIND_BY_PARTITO;
import static ministri.Ministri.FIND_BY_PORTAFOGLIO;
import static ministri.Ministri.FIND_BY_SOTTOSEGRETARIO;

/**
 *
 * @author corso-pd
 */
@Entity
@NamedQueries({
    @NamedQuery(name=FIND_ALL, query="SELECT m FROM Ministri m"),
    @NamedQuery(name=FIND_BY_ID, query="SELECT m FROM Ministri m WHERE m.id=?1"),
    @NamedQuery(name=FIND_BY_COGNOME, query="SELECT m FROM Ministri m WHERE m.cognome = :cognome"),
    @NamedQuery(name=FIND_BY_PARTITO, query="SELECT m FROM Ministri m WHERE m.partito = :partito"),
    @NamedQuery(name=FIND_BY_MINISTERO, query="SELECT m FROM Ministri m WHERE m.ministero = :ministero"),
    @NamedQuery(name=FIND_BY_PORTAFOGLIO, query="SELECT m FROM Ministri m WHERE m.portafoglio = TRUE"),
    @NamedQuery(name=FIND_BY_SOTTOSEGRETARIO, query="SELECT m FROM Ministri m WHERE m.numeroSottosegretari > :numeroSottosegretari"),
    @NamedQuery(name=FIND_BY_DIPENDENTI, query="SELECT m FROM Ministri m WHERE m.numeroDipendenti > :numeroDipendenti")
})
public class Ministri implements Serializable {
    public static final String FIND_ALL = "Ministri.findAll";
    public static final String FIND_BY_ID = "Ministri.findById";
    public static final String FIND_BY_COGNOME = "Ministri.findByCognome";
    public static final String FIND_BY_PARTITO = "Ministri.findByPartito";
    public static final String FIND_BY_MINISTERO = "Ministri.findByMinistero";
    public static final String FIND_BY_PORTAFOGLIO = "Ministri.findByPortafoglio";
    public static final String FIND_BY_SOTTOSEGRETARIO = "Ministri.findBySottosegretario";
    public static final String FIND_BY_DIPENDENTI = "Ministri.findByMinistri";
    public Ministri(){
    }

    public Ministri(int id, String cognome, String nome, String ministero, int numeroSottosegretari, int interesseRecoveryFound, boolean portafoglio, int numeroDipendenti, Partito partito) {
        this.id=id;
        this.cognome = cognome;
        this.nome = nome;
        this.ministero = ministero;
        this.numeroSottosegretari = numeroSottosegretari;
        this.interesseRecoveryFound = interesseRecoveryFound;
        this.portafoglio = portafoglio;
        this.numeroDipendenti = numeroDipendenti;
        this.partito = partito;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMinistero() {
        return ministero;
    }

    public void setMinistero(String ministero) {
        this.ministero = ministero;
    }

    public int getNumeroSottosegretari() {
        return numeroSottosegretari;
    }

    public void setNumeroSottosegretari(int numeroSottosegretari) {
        this.numeroSottosegretari = numeroSottosegretari;
    }

    public int getInteresseRecoveryFound() {
        return interesseRecoveryFound;
    }

    public void setInteresseRecoveryFound(int interesseRecoveryFound) {
        this.interesseRecoveryFound = interesseRecoveryFound;
    }

    public boolean isPortafoglio() {
        return portafoglio;
    }

    public void setPortafoglio(boolean portafoglio) {
        this.portafoglio = portafoglio;
    }

    public int getNumeroDipendenti() {
        return numeroDipendenti;
    }

    public void setNumeroDipendenti(int numeroDipendenti) {
        this.numeroDipendenti = numeroDipendenti;
    }

    public Partito getPartito() {
        return partito;
    }

    public void setPartito(Partito partito) {
        this.partito = partito;
    }

    @Override
    public String toString() {
        return "Ministri{" + "id=" + id + ", cognome=" + cognome + ", nome=" + nome + ", ministero=" + ministero + ", numeroSottosegretari=" + numeroSottosegretari + ", interesseRecoveryFound=" + interesseRecoveryFound + ", portafoglio=" + portafoglio + ", numeroDipendenti=" + numeroDipendenti + ", partito=" + partito + '}';
    }
    @Id
    int id;
    @NotNull
    private String cognome;
    private String nome;
    private String ministero;
    private int numeroSottosegretari; //nome cambiato
    private int interesseRecoveryFound; //nome cambiato
    private boolean portafoglio;
    private int numeroDipendenti; //nome cambiato
    @Enumerated(EnumType.STRING)
    private Partito partito;
}
