/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministriclientstd;

import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import ministri.Ministri;
import ministri.MinistriRemote;
import ministri.Partito;

/**
 *
 * @author corso-pd
 */
public class MinistriClientStd {
    // eliminato l'annotazione di inject superflua
    private static MinistriRemote ejb;
    public static void main(String[] args) throws NamingException { // aggiunto il throws
        Context context = new InitialContext();
        ejb = (MinistriRemote) context.lookup("java:global/GovernoEJB/MinistriEJB!ministri.MinistriRemote"); //aggiunto cast al lookup
        System.out.println("\n");
        System.out.println("Adesso stampo tutti i ministri con più di due sottosegretari");
        int numeroSottosegretari = 2;
        List<Ministri> invocazione1 = ejb.findBySottosegretario(numeroSottosegretari); //dimenticato questa dicitura
        for(Ministri m : invocazione1){
            System.out.println(m);
        }
        System.out.println("\n");
        System.out.println("Adesso stampo tutti i ministri che appartengono al PD e al M5S");
        Partito p = Partito.PD;
        List<Ministri> invocazione2 = ejb.findByPartito(p); //dimenticato questa dicitura
        for(Ministri m : invocazione2){
            System.out.println(m);
        }
       
        Partito p2 = Partito.M5S;
        List<Ministri> invocazione3 = ejb.findByPartito(p2); //dimenticato questa dicitura
        for(Ministri m : invocazione3){
            System.out.println(m);
        }
        System.out.println("\n");
        System.out.println("Vuoi un ministro che deve avere almeno quanti dipendenti?");
        Scanner mnt = new Scanner(System.in);
        int dipendenti;
        dipendenti = mnt.nextInt();
        List<Ministri> invocazione4 = ejb.findByDipendenti(dipendenti); //dimenticato questa dicitura
        for(Ministri m : invocazione4){
            System.out.println(m);
        }
    }
    
}
