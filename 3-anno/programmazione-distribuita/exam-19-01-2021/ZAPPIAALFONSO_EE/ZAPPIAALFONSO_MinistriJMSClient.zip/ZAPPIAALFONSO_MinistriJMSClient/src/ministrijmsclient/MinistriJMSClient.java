    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministrijmsclient;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import ministri.MessageWrapper;

/**
 *
 * @author corso-pd
 */
public class MinistriJMSClient {
    public static void main(String[] args) throws NamingException { //ho dimenticato di anticipare il main e di mettere il throws
        Context context = new InitialContext();
        ConnectionFactory cf = (ConnectionFactory) context.lookup("jms/javaee7/ConnectionFactory"); //aggiunto il casting
        Destination topic = (Destination) context.lookup("jms/javaee7/Topic"); //cambiato il nome della variabile
        MessageWrapper msg = new MessageWrapper(5, 55, 8); //ho dimenticato di passare i parametri all'oggetto
        try(JMSContext jmsc = cf.createContext()){
            jmsc.createProducer().send(topic, msg);
        }
    }
    
}
