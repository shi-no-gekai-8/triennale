/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author corso-pd
 */
@MessageDriven(mappedName = "jms/javaee7/Topic")
public class MinistriMDB implements MessageListener {
    @Inject
    Event<Ministri> updateEvent;
    @Inject
    private MinistriEJB random;
    @Inject @RecoveryFoundQualifier
    Event<Ministri> recoveryFoundEvent;
    @Inject @EuropeistaQualifier
    Event<Ministri> europeistaEvent;
    // corretta la giusta scrittura delle iniezioni di dipendenza
    @Override
    public void onMessage(Message msg){
        try{
            MessageWrapper msgContent = (MessageWrapper) msg.getBody(MessageWrapper.class); //effettuato il cast
            int id = msgContent.getId();
            Ministri m = random.findById(id);
            m.setNumeroDipendenti(msgContent.getAggiuntaDipendenti());
            if(msgContent.getAggiornamentoRecoveryFound()>=5 && !m.isPortafoglio()){
                recoveryFoundEvent.fire(m);
            } else{
                m.setInteresseRecoveryFound(msgContent.getAggiornamentoRecoveryFound());
                if(m.getInteresseRecoveryFound()>=7 && m.getPartito().equals(Partito.Lega)){
                    europeistaEvent.fire(m);
                }
            }
            random.updateMinistro(m); // ho dimenticato di modificare i dati
            updateEvent.fire(m);
            //corretti i controlli all'interno delle condizioni
        } catch(JMSException e){
             Logger.getLogger(MinistriMDB.class.getName()).log(Level.SEVERE, null, e); //cambiato il metodo di cattura di un'eccezione
        }
    }
}
