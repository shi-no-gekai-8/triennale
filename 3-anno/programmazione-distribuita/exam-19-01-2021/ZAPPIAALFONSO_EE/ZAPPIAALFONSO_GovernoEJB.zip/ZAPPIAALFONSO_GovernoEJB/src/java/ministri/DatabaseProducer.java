/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.enterprise.inject.Produces;

/**
 *
 * @author corso-pd
 */
public class DatabaseProducer {
    @Produces
    @PersistenceContext(unitName = "EsamePU")
    private EntityManager em;
}
