/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import javax.enterprise.event.Observes;

/**
 *
 * @author corso-pd
 */
public class NoticeRecoveryFound {
    public void notify(@Observes @RecoveryFoundQualifier Ministri m){ //aggiunto il qualifier
            System.out.println("Non è possibile aumentare l’interesse al Recovery Fund oltre 5 per un ministro senza portafogli");
    }
}
