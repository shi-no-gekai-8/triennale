/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

/**
 *
 * @author corso-pd
 */
@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:app/jdbc/EsameDS",
   user = "fonzza08", password = "fonzza08",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    @Inject
    private MinistriEJB ejb;
    private Ministri m1, m2, m3, m4, m5; //creati per JMS
    @PostConstruct
    private void populateDB(){
       m1 = new Ministri(1, "Di Maio", "Luigi", "Esteri", 3, 9, true, 1200, Partito.M5S);
       m2 = new Ministri(2, "Lamorgese", "Luciana", "Interni", 2, 4, true, 8200, Partito.Tecnici);
       m3 = new Ministri(3, "Brunetta", "Renato", "Pubblica Amministrazioni", 1, 4, false, 0, Partito.FI);
       m4 = new Ministri(4, "Guerini", "Lorenzo", "Difesa", 2, 5, false, 0, Partito.PD); //creato per JMS
       m5 = new Ministri(5, "Giorgetti", "Giancarlo", "Sviluppo Economico", 4, 6, true, 50, Partito.Lega); //creato per JMS
       ejb.addMinistro(m1);
       ejb.addMinistro(m2);
       ejb.addMinistro(m3);
       ejb.addMinistro(m4); //creati per JMS
       ejb.addMinistro(m5); //creati per JMS
    }
    @PreDestroy
    private void clearDB(){
        ejb.removeMinistro(m1);
        ejb.removeMinistro(m2);
        ejb.removeMinistro(m3);
        ejb.removeMinistro(m4); //creati per JMS
        ejb.removeMinistro(m5); //creati per JMS
    }
}
