/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import java.io.Serializable;

/**
 *
 * @author corso-pd
 */
public class MessageWrapper implements Serializable {
       private int id;
       private int aggiuntaDipendenti;
       private int aggiornamentoRecoveryFound;
       // ho inserito anche la variabile partito nell'esame, ma non era necessario

    public MessageWrapper(int id, int aggiuntaDipendenti, int aggiornamentoRecoveryFound) {
        this.id = id;
        this.aggiuntaDipendenti = aggiuntaDipendenti;
        this.aggiornamentoRecoveryFound = aggiornamentoRecoveryFound;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAggiuntaDipendenti() {
        return aggiuntaDipendenti;
    }

    public void setAggiuntaDipendenti(int aggiuntaDipendenti) {
        this.aggiuntaDipendenti = aggiuntaDipendenti;
    }

    public int getAggiornamentoRecoveryFound() {
        return aggiornamentoRecoveryFound;
    }

    public void setAggiornamentoRecoveryFound(int aggiornamentoRecoveryFound) {
        this.aggiornamentoRecoveryFound = aggiornamentoRecoveryFound;
    }

    @Override
    public String toString() {
        return "MessageWrapper{" + "id=" + id + ", aggiuntaDipendenti=" + aggiuntaDipendenti + ", aggiornamentoRecoveryFound=" + aggiornamentoRecoveryFound + '}';
    }
    // ho aggiunto il costruttore, i getters e i setters e il toString(), non inseriti all'interno dell'esame
}
