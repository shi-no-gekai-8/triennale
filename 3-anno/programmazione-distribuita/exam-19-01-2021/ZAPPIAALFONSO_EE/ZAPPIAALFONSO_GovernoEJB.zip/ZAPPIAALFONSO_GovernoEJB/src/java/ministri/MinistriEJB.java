/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

/**
 *
 * @author corso-pd
 */
@Stateless
@LocalBean
public class MinistriEJB implements MinistriRemote {
    @Inject
    private EntityManager em;
    @Override
    public void addMinistro(Ministri m) {
        em.persist(m); //ho sbagliato lettera
    }
    
    @Override
    public void removeMinistro(Ministri m) {
        em.remove(em.merge(m)); //ho sbagliato lettera
    }

    @Override
    public void updateMinistro(Ministri m) {
        em.merge(m); //ho sbagliato lettera
    }

    @Override
    public List<Ministri> findAll() {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_ALL, Ministri.class);
        return query.getResultList();
    }

    @Override
    public Ministri findById(int id) {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_ID, Ministri.class);
        query.setParameter(1, id); //valori errati nell'esame
        return query.getSingleResult();
    }

    @Override
    public List<Ministri> findByCognome(String c) {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_COGNOME, Ministri.class);
        query.setParameter("cognome", c);
        return query.getResultList();
    }

    @Override
    public List<Ministri> findByPartito(Partito p) {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_PARTITO, Ministri.class);
        query.setParameter("partito", p);
        return query.getResultList();
    }

    @Override
    public Ministri findByMinistero(String m) {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_MINISTERO, Ministri.class);
        query.setParameter("ministero", m);
        return query.getSingleResult();
    }

    @Override
    public List<Ministri> findByPortafogli() { // impostazione sbagliata nell'esame
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_PORTAFOGLIO, Ministri.class);
        return query.getResultList(); //all'esame ho aggiunto il setParameter quando non era necessario
    }

    @Override
    public List<Ministri> findBySottosegretario(int s) { // ho dimenticato di passargli s in input
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_SOTTOSEGRETARIO, Ministri.class);
        query.setParameter("numeroSottosegretari", s); //ho dimenticato di settare il parametro
        return query.getResultList();
    }

    @Override
    public List<Ministri> findByDipendenti(int d) {
        TypedQuery<Ministri> query = em.createNamedQuery(Ministri.FIND_BY_DIPENDENTI, Ministri.class);
        query.setParameter("numeroDipendenti", d);
        return query.getResultList();
    }
    
}
