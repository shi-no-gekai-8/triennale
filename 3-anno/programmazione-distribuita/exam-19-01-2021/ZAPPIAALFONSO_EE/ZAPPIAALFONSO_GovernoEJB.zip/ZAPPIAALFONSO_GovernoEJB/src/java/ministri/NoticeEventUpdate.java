/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;

import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author corso-pd
 */
public class NoticeEventUpdate {
    @Inject
    private MinistriEJB ejb;
    public void notify(@Observes Ministri m){
        System.out.println(m.getId()+" è stato modificato");        
    }
}
