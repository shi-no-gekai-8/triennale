/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministri;
//sono stati aggiunti tutti gli import mancanti all'esame
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author corso-pd
 */
@Remote
public interface MinistriRemote {
    void addMinistro(Ministri m);
    void removeMinistro(Ministri m);
    void updateMinistro(Ministri m);
    List<Ministri> findAll();
    Ministri findById(int id);
    List<Ministri> findByCognome(String c);
    List<Ministri> findByPartito(Partito p);
    Ministri findByMinistero(String m);
    List<Ministri> findByPortafogli(); // ho corretto questo metodo impostato male
    List<Ministri> findBySottosegretario(int s);
    List<Ministri> findByDipendenti(int d);
}
